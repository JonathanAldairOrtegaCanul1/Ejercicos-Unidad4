import re


def pedirNumeroEntero():

    correcto = False
    num = 0
    while not correcto:
        try:
            num = int(input("Introduce un numero entero: "))
            correcto = True
        except ValueError:
            print("Error, introduce un numero entero")

    return num


salir = False
opcion = 0

while not salir:
    print ("_____________________EXPRESIONES REGULARES_____________________")
    print("1. Variables válidas")
    print("2. Enteros y decimales")
    print("3. Operadores aritmeticos")
    print("4. Operadores relacionales")
    print("5. Palabras relacionales")
    print("6. Salir")


    print("Elige una opcion")

    opcion = pedirNumeroEntero()

    if opcion == 1:
        print("Variables validas")
        f = open(
            "archivo.txt"
        ).read()
        ExpReg = r'(\b[A-Za-z0-9-_]+\s*[=])+'  
        exp = re.findall(ExpReg, f, flags=re.MULTILINE)
        print(exp)

    elif opcion == 2:
        print ("Enteros y decimales")
        f = open(
            "archivo.txt"
        ).read()
        ExpRegEnt = r'[+,-]?[0-9]+'
        ExpRegDec = r'[+,-]?[[0-9]*[.]]?[0-9]+'
        expEnt = re.findall(ExpRegEnt, f, flags=re.MULTILINE)
        expDec = re.findall(ExpRegDec, f, flags=re.MULTILINE)
        print (expEnt)
        print (expDec)
     
    elif opcion == 3:
        print ("Operadores aritmeticos")
        f = open(
            "archivo.txt"
        ).read()
        ExpReg = r'[\d+]+\s*[\+|\-|\*|\/|\%]+\s*[\d+]+'
        exp = re.findall(ExpReg, f, flags=re.MULTILINE)
        print (exp)

    elif opcion == 4:
        print("Operadores relacionales")    
        f = open(
            "archivo.txt"
        ).read()
        ExpReg = r'([A-Za-z0-9|a-z0-9]+\s*[|<|>|!=|<=|>=|==]+\s*[A-Za-z0-9|a-z0-9])+'
        exp = re.findall(ExpReg, f, flags=re.MULTILINE)
        print (exp)

    elif opcion == 5:
        print("Palabras Relacionales")
        f = open(
            "archivo.txt"
        ).read()
        ExpReg = r'\b(False|def|if|raise|None|del|import|return|True|elif|in|try|and|else|is|while|as|except|lambda|with|assert|finally|nonlocal|yield|break|for|not|class|from|or|continue|global|pass\s)+|\s[:]+'
        exp = re.findall(ExpReg, f, flags=re.MULTILINE)
        print (exp)

    elif opcion == 6:
        salir = True
    else:
        print("Introduce un numero entre 1 y 6")

print("Fin")
